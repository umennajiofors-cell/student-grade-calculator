# Student Grade Calculator

A beginner-friendly Python program that calculates a student's letter grade and pass/fail status from a score out of 100.

## Features
- Accepts a student's name and score.
- Checks that the score is between 0 and 100.
- Assigns a letter grade.
- Displays whether the student passed or failed.

## Grade Scale

| Score | Grade |
|---|---|
| 70–100 | A |
| 60–69 | B |
| 50–59 | C |
| 45–49 | D |
| 40–44 | E |
| 0–39 | F |

## Requirements
- Python 3.8 or later

## How to Run
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   python main.py
   ```

## Example

```text
=== Student Grade Calculator ===
Enter student name: Somto
Enter score (0-100): 76

--- Result ---
Student: Somto
Score: 76/100
Grade: A
Status: Pass
```

## Concepts Practised
Python functions, conditional statements, user input, exception handling, and basic program structure.
