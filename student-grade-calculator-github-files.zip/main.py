"""Student Grade Calculator
A beginner-friendly Python project for calculating grades and pass/fail status.
"""

def calculate_grade(score: float) -> str:
    """Return a letter grade for a score from 0 to 100."""
    if not 0 <= score <= 100:
        raise ValueError("Score must be between 0 and 100.")
    if score >= 70:
        return "A"
    elif score >= 60:
        return "B"
    elif score >= 50:
        return "C"
    elif score >= 45:
        return "D"
    elif score >= 40:
        return "E"
    return "F"


def main() -> None:
    print("=== Student Grade Calculator ===")
    name = input("Enter student name: ").strip()

    try:
        score = float(input("Enter score (0-100): "))
        grade = calculate_grade(score)
    except ValueError as error:
        print(f"Invalid input: {error}")
        return

    status = "Pass" if score >= 40 else "Fail"
    print("\n--- Result ---")
    print(f"Student: {name or 'Student'}")
    print(f"Score: {score:g}/100")
    print(f"Grade: {grade}")
    print(f"Status: {status}")


if __name__ == "__main__":
    main()
